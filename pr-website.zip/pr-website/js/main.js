// P&R Political Consulting Group — site scripts

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Mobile menu
const toggle = document.querySelector(".nav-toggle");
const nav = document.querySelector(".main-nav");
toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", open);
  toggle.innerHTML = open ? '<i class="fa-solid fa-xmark"></i>' : '<i class="fa-solid fa-bars"></i>';
});
nav.querySelectorAll("a").forEach((link) =>
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
  })
);

// Fade-in sections as they scroll into view
const revealTargets = document.querySelectorAll(
  ".section-head, .about .container, .service-card, .team-card, .audit-form"
);
if ("IntersectionObserver" in window) {
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          io.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );
  revealTargets.forEach((el) => {
    el.classList.add("reveal");
    io.observe(el);
  });
}

// Audit form — submits to Formspree without leaving the page
const form = document.querySelector(".audit-form");
const status = form.querySelector(".form-status");

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  if (form.action.includes("YOUR_FORM_ID")) {
    status.textContent = "Form not connected yet — add your Formspree ID in index.html.";
    return;
  }

  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  button.textContent = "Sending...";

  try {
    const res = await fetch(form.action, {
      method: "POST",
      body: new FormData(form),
      headers: { Accept: "application/json" },
    });
    if (res.ok) {
      form.reset();
      status.textContent = "Thanks! We'll be in touch within 1–2 business days.";
    } else {
      status.textContent = "Something went wrong. Please try again or email us directly.";
    }
  } catch {
    status.textContent = "Network error. Please try again.";
  } finally {
    button.disabled = false;
    button.textContent = "Request Your Free Starter Audit";
  }
});
